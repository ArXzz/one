public class Operadoresdeconparacion {
    public static void main(String[] args) {
        int numero1 = 10;
        int numero2 = 20;

        System.out.println("¿numero1 es igual a numero2? " + (numero1==numero2));
        System.out.println("¿numero1 es diferente a numero2? " + (numero1!=numero2));
        System.out.println("¿numero1 es mayor que numero2? " + (numero1>numero2));
        System.out.println("¿numero1 es menor que numero2? " + (numero1<numero2));
        System.out.println("¿numero1 es mayor igual que numero2? " + (numero1>=numero2));
        System.out.println("¿numero1 es menor igual que numero2? " + (numero1<=numero2));
    }
    
}
